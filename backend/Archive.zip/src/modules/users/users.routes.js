import { Router } from "express";

import UsersController from "./users.controller.js";
import AuthMiddleware from "../../middleware/auth.middleware.js";

const router = Router();

router.get(

    "/me",

    AuthMiddleware.authenticate,

    UsersController.me

);

export default router;
