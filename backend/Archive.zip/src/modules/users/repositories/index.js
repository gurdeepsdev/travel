import usersRepository from "../users.repository.js";
import profilesRepository from "./profiles.repository.js";

export {
    usersRepository,
    profilesRepository
};