import Response from "../../core/response/index.js";
import ProfileService from "./services/profile.service.js";

class UsersController {

    async me(req, res, next) {

        try {

            const profile = await ProfileService.getMyProfile(
                req.user.id
            );

            return Response.success(

                res,

                {
                    profile
                },

                "Profile fetched successfully."

            );

        } catch (error) {

            next(error);

        }

    }

}

export default new UsersController();
